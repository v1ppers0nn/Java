
public class StringType {
	public static void main(String[] args) {
		String firstName = "Ivan";
		String lastName = "Ivanov";
		System.out.println("Hello, " + firstName);

		String fullName = firstName + " " + lastName;
		System.out.println("Your full name is: " + fullName);

		int age = 21;
		System.out.println("Hello, I am " + age + " years old");
	}
}
