
public class IntegerTypes {
	public static void main(String[] args) {
		byte b = 1;
		int i = 5;
		long num = 3L;
		short sum = (short) (b + i + num);

		System.out.println(b);
		System.out.println(i);
		System.out.println(num);
		System.out.println(sum);
	}
}
