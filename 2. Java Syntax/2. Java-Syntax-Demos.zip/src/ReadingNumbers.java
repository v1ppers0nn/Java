import java.util.Scanner;

public class ReadingNumbers {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int firstNum = input.nextInt();
		int secondNum = input.nextInt();
		
		System.out.println(firstNum);
		System.out.println(secondNum);
	}
}
