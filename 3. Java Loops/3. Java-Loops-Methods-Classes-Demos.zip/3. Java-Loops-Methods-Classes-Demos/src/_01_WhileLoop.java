public class _01_WhileLoop {
	public static void main(String[] args) {
		int counter = 0;
		while (counter < 10) {
		    System.out.printf("Number : %d\n", counter);
		    counter++;
		}
	}
}
